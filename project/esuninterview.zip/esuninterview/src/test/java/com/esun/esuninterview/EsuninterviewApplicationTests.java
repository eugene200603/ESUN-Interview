package com.esun.esuninterview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsuninterviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
